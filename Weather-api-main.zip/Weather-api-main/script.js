let KEY = 'dea9c36d4ff318cfb04203de9c44a054'; // OpenWeatherMap API key
let city;
let inpValue;

$('.weatherInfo').hide(); // Initially hide the weather information section

$('.findBtn').click(function(){
    if(cityInp.value === '') {
        alert('Enter the city!');
    } else {
        city = cityInp.value;
        fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${KEY}`)
        .then((response) => {
          return response.json();
        })
        .then((data) => {
          if(data.cod === 200) {
            inpValue = true;
            $('.weatherInfo').fadeIn(800); // Fade in the weather info section
            $('.card').css('left', '79%'); // Move the card to the left
            $('.cityTxt').text(data.name);
            $('.countryTxt').text(data.sys.country);
            $('.actTemp').text((data.main.temp - 273.15).toFixed(2) + ' °C');
            $('.feelTemp').text((data.main.feels_like - 273.15).toFixed(2) + ' °C');
            $('.skyTxt').text(data.weather[0].description);
            $('.windTxt').text('Wind speed: ' + data.wind.speed + ' m/s');
            $('.preTxt').text('Pressure: ' + data.main.pressure + ' hPa');
            let windDeg = data.wind.deg + 'deg';
            $('.windImg').css('transform', `rotate(${windDeg})`);
            let skyVal = data.weather[0].icon + '.png';
            $('.skyImg').css('background-image', `url('img/${skyVal}')`); 
          } else {
            alert('Incorrect data!');
          }
        });
    }
});

$('#cityInp').click(function(){
    if(inpValue === true) {
        inpValue = false;
    }
    $('.card').css('left', '50%'); // Reset the card position
    $('.weatherInfo').fadeOut(100); // Fade out the weather info section
});
